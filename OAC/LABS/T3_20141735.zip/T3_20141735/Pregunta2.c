#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define N 500
void transpuestaRowMajor(int M[][N], int MT[][N]);
void transpuestaColumnMajor(int M[][N], int MT[][N]);
void imprimirMatrices(int M[][N],int MT[][N]);
void ordenar(float A[]);

int main(){
	srand(time(NULL));
	int M[N][N];
    int MT[N][N];
	float A[10], B[10];
    
    //llenar matriz
    for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			M[i][j]= rand()%(N+1); 
		}
	}
    
	for(int i=0;i<10;i++){
		//transpuesta en row major
		clock_t inicioR,finR,totalR;

		inicioR=clock();
		transpuestaRowMajor(M,MT);
		finR= clock();
		totalR= finR - inicioR;

		A[i]=1000000*((float)totalR)/CLOCKS_PER_SEC;

		//transpuesta en column major
		clock_t inicioC, finC, totalC;

		inicioC= clock();
		transpuestaColumnMajor(M,MT);
		finC= clock();
		totalC= finC - inicioC;

		B[i]=1000000*((float)totalC)/CLOCKS_PER_SEC;
	}

    imprimirMatrices(M,MT);

	//Pregunta A
	ordenar(A);
	printf("Mediana del Row major: %.3f ns \n", (A[4]+A[5])/2);

	ordenar(B);
	printf("Mediana del Column major: %.3f ns \n", (B[4]+B[5])/2);

	return 0;
}

void imprimirMatrices(int M[][N],int MT[][N]){

    printf("Matriz original: \n");

	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++)
			printf("%4d",M[i][j]);
		printf("\n");
	}

	printf("Matriz Transpuesta\n");
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++)
			printf("%4d",MT[i][j]);
		printf("\n");
	}
	printf("\n");
}

void transpuestaRowMajor(int M[][N], int MT[][N]){
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			MT[j][i]=M[i][j];
		}
	}

}

void transpuestaColumnMajor(int M[][N], int MT[][N]){
	int i,j;
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			MT[i][j]=M[j][i];
		}
	}
}
//uso bubble sort ya que solo estoy ordenando 10 elementos
void ordenar(float A[]){
	int i,j;
	for(i=0;i<10-1;i++){
		for(j=i+1;j<10;j++){
			if (A[i]>A[j]){
				float aux= A[i];
				A[i]= A[j];
				A[j]= aux;
			}
		}
	}
}

