#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void mulRowMajor(int N,int A[][N],int B[][N],int C[][N]);
void mulColumnMajor(int N,int A[][N],int B[][N],int C[][N]);
void ordenar(float t[]);

int main(){
	srand(time(NULL));
	int N;
	printf("Ingrese el valor de N: ");
	scanf("%d",&N);

	int A[N][N],B[N][N],C[N][N];
	float tR[10],tC[10];
	
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			A[i][j]= rand()%(N+1);
			B[i][j]= rand()%(N+1);
		}
	}

	int i;
	for(i=0;i<10;i++){
		//mulitpicacion en row major
		clock_t inicioR,finR,totalR;

		inicioR=clock();
		mulRowMajor(N,A,B,C);
		finR= clock();
		totalR= finR - inicioR;

		tR[i]=1000000*((float)totalR)/CLOCKS_PER_SEC;

		//multiplicacion en column major
		clock_t inicioC, finC, totalC;

		inicioC= clock();
		mulColumnMajor(N,A,B,C);
		finC= clock();
		totalC= finC - inicioC;

		tC[i]=1000000*((float)totalC)/CLOCKS_PER_SEC;
	}
	
	ordenar(tR);
	printf("Mediana de los tiempos de ejecucion en ROW MAJOR: %.4f us\n",(tR[4]+tR[5])/2);

	ordenar(tC);
	printf("Mediana de los tiempos de ejecucion en COLUMN MAJOR: %.4f us\n",(tC[4]+tC[5])/2);
	return 0;
}


void mulRowMajor(int N,int A[][N],int B[][N],int C[][N]){

	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			int mul=0;
			for(int k=0;k<N;k++){
				mul+=A[i][k]*B[k][j];
			}
		C[i][j]= mul;
		}
	}
}
void mulColumnMajor(int N,int A[][N],int B[][N],int C[][N]){

	for(int j=0;j<N;j++){
		for(int i=0;i<N;i++){
			int mul=0;
			for(int k=0;k<N;k++)
				mul+=A[i][k]*B[k][j];
		C[i][j]=mul;
		}
	}
}
void ordenar(float t[]){
	float aux;
	for(int i=0;i<10-1;i++){
		for(int j=i+1;j<10;j++){
			if (t[i]>t[j]){
				aux= t[i];
				t[i]= t[j];
				t[j]= aux;
			}
		}
	}
}

