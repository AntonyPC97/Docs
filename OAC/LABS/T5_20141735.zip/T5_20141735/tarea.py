import pyautogui as auto
import time

print('Posicione el cursor para dar inicio al juego.')
#funcion que establece los limites de la parte superior del laberinto
def derecha():
    x,y = auto.position()
    if(x>284) and (x<1037) and (y>227) and (y<267):
        return True
    return False

#funcion que establece los limites de la parte lateral derecha del laberinto
def abajo():
    x,y = auto.position()
    if(x>994) and (x<1037) and (y>227) and (y<642):
        return True
    return False

#funcion que establece los limites de la parte inferior del laberinto
def izquierda():
    x,y = auto.position()
    if(x>284) and (x<1037) and (y>600) and (y<640):
        return True
    return False

#funcion que establece los limites de la parte lateral izquierda del laberinto
def arriba():
    x,y = auto.position()
    if(x>284) and (x<324) and (y>307) and (y<640):
        return True
    return False


if(auto.confirm('Elija  una  opcion ', buttons =['Simulador', 'Usuario'])=='Simulador'): 
    #Escogió Simulador  
    x = 305
    y = 245
    inicio=time.time()
    #Mover cursor a la entrada
    auto.moveTo (x,y, duration =0.5)
    
    #recorrer laberinto
    auto.moveTo (x + 720,y, duration =1)
    auto.moveTo (x+720,y+380, duration =1)
    auto.moveTo (x,y+380, duration =1)
    auto.moveTo (x,y+80, duration =1)
    fin=time.time()
    total = fin-inicio
    cadena = 'Ganaste en un tiempo de ' + str(total) +' segundos'
    auto.confirm(text = cadena, buttons =['OK'])
else: 

    try:
        x = 305
        y = 245
        inicio=time.time()
        #Mover cursor a la entrada
        auto.moveTo (x,y, duration =0.5)
        #Utilizo las funciones que establece el limite de cada porcion del labernto
        #en caso se salga, imprime el mensaje
        while True:
            if(not derecha()):
                if(not abajo()):
                    if(not izquierda()):
                        if(not arriba()):
                            auto.confirm(text = 'Te has pasado de los límites del camino', buttons =['OK'])
                            auto.moveTo (x,y, duration =0)
            
            #imprimo contiuamente la posicion del cursor
            currentMouseX, currentMouseY = auto.position()
            positionStr = '(' + str(currentMouseX) + ',' + str(currentMouseY) + ')'
            print(positionStr, end='\n')
            
            fin=time.time()

            #limites del cuadrado de llegada
            winminX = 284
            winmaxX = 324
            winminY = 307
            winmaxY = 347

            #Una vez entre al cuadrado, imprime el mensaje de victoria y termina el juego
            if(currentMouseX<winmaxX) and (currentMouseX>winminX) and (currentMouseY<winmaxY) and (currentMouseY>winminY):
                fin = time.time()
                total = fin-inicio
                cadena = 'Ganaste en un tiempo de ' + str(total) +' segundos'
                auto.confirm(text = cadena, buttons =['OK'])
                break
    except KeyboardInterrupt:
        print('\n')

