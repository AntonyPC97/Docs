import pyautogui as auto
import time
import random as random
import math 

def escribir(entrada,car):
    entrada.write(car)


def main():
    inicio = time.time()
    f = open("byte16kib.txt","w")
    a= 'a'*(int(math.pow(2,14))-1) + '\n'
    for i in range(int(math.pow(2,10))):
        escribir(f,a)
    for i in range(int(math.pow(2,5))):
        escribir(f,a)
    total = time.time()-inicio
    print("Tiempo de ejecucion fue de "+str(total)+" segundos.")

if (__name__ =="__main__"):
    main()