//20141735 - Antony Palacios
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void normaC(float *x, float *resultado, int N);
void imprimirValores(float *x, int N);
extern void normaAsm(float*x,float *resultado, int N);

int main(){
    srand(time(NULL));
    int N=16;
    float *x,l,*resultado;
    resultado = malloc(sizeof(float));

    posix_memalign((void**)&x,16,N*sizeof(float));

	for(int i=0;i<N;i++){
		l=(float)(rand()%100);
		l=((sinf(l)+cosf(l))/1.4142)*10;
		x[i]=l;
	}
    imprimirValores(x,N);
    
    clock_t inicioC = clock();
    normaC(x,resultado,N);
    clock_t finC = clock() - inicioC;

    printf("La norma a 2 del vector X en C es: %.4f\n",*resultado);
    printf("El tiempo de ejecucion en C es: %.4f ns\n",1000000*(( float)finC)/CLOCKS_PER_SEC);

    clock_t inicioAsm = clock();
    normaAsm(x,resultado,N);
    clock_t finAsm = clock() - inicioAsm;

    printf("La norma a 2 del vector X en ASM es: %.4f\n",*resultado);
    printf("El tiempo de ejecucion en ASM es: %.4f ns\n",1000000*(( float)finAsm)/CLOCKS_PER_SEC);

    printf("SpeedUp: %.4f\n",(float)finC/finAsm);

    return 0;
}

void normaC(float *x,float *resultado, int n){
    float suma = 0;
    for(int i=0;i<n;i++){
        suma += pow(x[i],2);
    }
    *resultado = sqrt(suma);
}

void imprimirValores(float *x,int n){

	printf("Vector X\n");
    for(int i=0;i<n;i++) 
        printf("%f\n",x[i]);
	printf("\n");
}