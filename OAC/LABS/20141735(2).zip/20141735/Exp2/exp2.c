#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void errorC(float *x,float *y, float *error, int N);
void vectoresRandom(float *v,int n);
void imprimirValores(float *x,float *y,int n);
//extern void normaAsm(float*x,float *resultado, int N);

int main(){
    int N=16;
    float *x,*y,*error;
    error = malloc(sizeof(float));

    posix_memalign((void**)&x,16,N*sizeof(float));
    posix_memalign((void**)&y,16,N*sizeof(float));

    vectoresRandom(x,N);
    vectoresRandom(y,N);
    imprimirValores(x,y,N);

    clock_t inicioC = clock();
    errorC(x,y,error,N);
    clock_t finC = clock() - inicioC;

    printf("El error relativo de los vectores en C es: %.4f\n",*error);
    printf("Tiempo de ejecucion en C es: %.4f ns\n",1000000*(( float)finC)/CLOCKS_PER_SEC);
    /*
    clock_t inicioAsm = clock();
    errorC(x,y,error,N);
    clock_t finAsm = clock() - inicioAsm;

    printf("El error relativo de los vectores en Asm es: %.4f\n",*error);
    printf("Tiempo de ejecucion en Asm es: %.4f ns\n",1000000*(( float)finAsm)/CLOCKS_PER_SEC);
    */
    return 0;
}

void  vectoresRandom(float *v, int  n){
	int i=0;
	float l=0;
	for(i=0;i<n;i++){
		l=(float)(rand()%100);
		l=((sinf(l)+cosf(l))/1.4142)*10;
		v[i]=l;
	}
}

void errorC(float *x,float *y, float *error, int n){
    float sumaXY = 0;
    float sumaY = 0;
    for(int i=0;i<n;i++){
        sumaXY += pow(x[i]-y[i],2);
        sumaY  += pow(y[i],2);
    }
    *error = sqrt(sumaXY)/sqrt(sumaY);
}

void imprimirValores(float *x,float *y,int n){

	printf("Vector X	   Vector Y  \n");
    for(int i=0;i<n;i++) 
        printf(" %f\t %f\n",x[i],y[i]);
	printf("\n");
}