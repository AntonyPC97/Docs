#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void vectoresRandom(float *v,int n);
void ProdC(float *v, float *u,float *w,int n);
extern void ProdAsm(float *v,float *u,float *w,int n); //usando solo ASM
extern void parcialAsm(float *v,float *u,float *w);
void ProdPacial(float *v,float *u,float *w,int n);
void imprimirValores(float *v,float *u,float *c,float *wasm,float *casm,int n);


int main(){
	srand(time(NULL));
	float *v,*u,*c,*wasm,*casm;
	int N=16;
	int i=0;

	posix_memalign((void**)&v,16,N*sizeof(float));
	posix_memalign((void**)&u,16,N*sizeof(float));
	posix_memalign((void**)&c,16,N*sizeof(float));
	posix_memalign((void**)&wasm,16,N*sizeof(float));
	posix_memalign((void**)&casm,16,N*sizeof(float));

	vectoresRandom(v,N);
	vectoresRandom(u,N);
    
    clock_t incioC = clock();
	ProdC(v,u,c,N);
    clock_t finC = clock()-incioC;

    clock_t incioA = clock();
	ProdAsm(v,u,wasm,N);
    clock_t finA = clock()-incioA;

	ProdPacial(v,u,casm,N);
    imprimirValores(v,u,c,wasm,casm,N);

	float sumaC = 0;
	float sumaAsm = 0;
	for(i=0;i<N;i++){
		sumaC+=c[i];
		sumaAsm+=wasm[i];
	} 
	printf("Producto interno en C: %f\n",sumaC);
	printf("Tiempo de ejecucion usando C: %.4f us\n",1000000*(( float)finC)/CLOCKS_PER_SEC);

	printf("Producto interno en Asm: %f\n",sumaAsm);
	printf("Tiempo de ejecucion usando Asm: %.4f us\n",1000000*(( float)finA)/CLOCKS_PER_SEC);

	printf("SpeedUp: %.0f\n",((float)finC/finA));
	return 0;
}

void  vectoresRandom(float *v, int  n){
	int i=0;
	float l=0;
	for(i=0;i<n;i++){
		l=(float)(rand()%100);
		l=((sinf(l)+cosf(l))/1.4142)*10;
		v[i]=l;
	}
}

void imprimirValores(float *v,float *u,float *c,float *wasm,float *casm,int n){

	printf("Vector v	   Vector u  	ProdC	  	ProdAsm		ProdParcial\n");
    for(int i=0;i<n;i++) 
        printf(" %f\t %f\t %f\t %f\t %f\n",v[i],u[i],c[i],wasm[i],casm[i]);
	printf("\n");
}

void ProdC(float *v,float *u,float *w,int n){ //usando solo C
	for(int i=0;i<n;i++) 
        w[i]=v[i]*u[i];
}

void ProdPacial(float *v,float *u,float *w,int n){ //usando C y ASM
	for(int i=0;i<n;i+=4) 
        parcialAsm(&v[i],&u[i],&w[i]);
}
