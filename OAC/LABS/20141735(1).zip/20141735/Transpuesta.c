#include <stdio.h>
#include <stdlib.h>
//random del 1-5

//void matrizTranspuesta(int N, int bsize, int M[][N]);
void imprimir(int N,int A[][N]);

int main(int argc, char** argv){

    int N = atoi(argv[0]);
    int bsize = atoi(argv[1]);

    int M[N][N];
    for(int i=0;i<N;i++){
    	for(int j=0;j<N;j++){
    		M[i][j] = rand()%6 + 1;
    	}
    }
    printf("Matriz A:\n");
    imprimir(N,M);
    //matrizTranspuesta(M,bsize,N);
    //printf("Matriz A':\n");
    //imprimir(M,N);   
   	return 0;
}

void matrizTranspuesta(int N,int bsize, int M[][N]){
	int i,j,k,l,m,aux;
	//
	for(k=0;k<=N-bsize;k+=bsize){
		for(l=0;l<=N-bsize;l+=bsize){
			for(i = 0;i<bsize;i++){
				for(j=0;j<bsize;j++){
					aux = M[i][j];
					M[i][j] = M[j][i];
					M[j][i] = aux;
				}
			}	
		}
	}
	
}

void imprimir(int N,int M[][N]){
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			printf("%4d",M[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}



