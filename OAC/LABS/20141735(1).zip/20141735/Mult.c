#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void multiplicaB(int N,int bsize,int A[][N],int B[][N],int C[][N]);
void multiplica(int N,int A[][N],int B[][N],int C[][N]);

void imprimir(int N,int A[][N]);

int main(){
	srand(time(NULL));
	int N,bsize;
	printf("Ingrese el valor de N: ");
	scanf("%d",&N);
	printf("Ingrese el tamaño del bloque: ");
	scanf("%d",&bsize);
	float tiempoN,tiempoB;


	int A[N][N],B[N][N],C[N][N];
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			A[i][j]= rand()%(N+1);
			B[i][j]= rand()%(N+1);
			C[i][j] = 0;
		}
	}
	printf("Matriz A:\n");
	//imprimir(N,A);
	printf("MAtriz B:\n");
	//imprimir(N,B);
	multiplica(N,A,B,C);
	printf("Matriz C = AXB:\n");
	//imprimir(N,C);

	clock_t inicio,fin,total,inicioB,finB,totalB;


	inicio = clock();
	multiplica(N,A,B,C);
	fin = clock();
	total = inicio-fin;
	printf("Tiempo normal %.2f us\n",1000000*((float)total)/CLOCKS_PER_SEC);

	inicioB = clock();
	multiplicaB(N,bsize,A,B,C);
	finB = clock();
	totalB= inicioB-finB;
	printf("Tiempo con Blocking %.2f us\n",1000000*((float)totalB)/CLOCKS_PER_SEC);

	for(int i=0;i<99;i++){
		inicio = clock();
		multiplica(N,A,B,C);
		fin = clock();
		tiempoN+= (inicio-fin);

		inicioB = clock();
		multiplicaB(N,bsize,A,B,C);
		finB = clock();
		tiempoB+= (inicioB-finB);
	}
	float media = tiempoN/99;
	float mediaB = tiempoB/99;
	printf("Speedup %.2f",(mediaB-media)/media);

	return 0;
}

void multiplicaB(int N,int bsize,int A[][N],int B[][N],int C[][N]){
	for(int l=0;l<=N-bsize;l+=bsize){
		for(int m = 0;m<=N-bsize;m+=bsize){
			for(int i=0;i<bsize;i++){
				for(int j=0;j<bsize;j++){
					int mul=0;
					for(int k =0;k<bsize;k++)
						mul+=A[i][k]*B[k][j];
					C[l][m]+=mul;
				}
			}
		}
	}
}

void imprimir(int N, int A[][N]){
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			printf("%4d",A[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void multiplica(int N,int A[][N],int B[][N],int C[][N]){

	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			int mul=0;
			for(int k=0;k<N;k++){
				mul+=A[i][k]*B[k][j];
			}
		C[i][j]= mul;
		}
	}
}