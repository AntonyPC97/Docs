#include <stdio.h>
#include <stdlib.h>
#include <time.h>

extern void asmMayorNumero (int len , int *vector , int* max );
void cMayorNumero (int len , int *vector , int *max );
int main(void){

	int len=5;
	int* max =malloc(sizeof(int));
	int* vector = malloc(len*sizeof(int));
	vector[0] =5;
	vector[1] =6;
	vector[2] =7;
	vector[3] =2;
	vector[4] =3;
	cMayorNumero(len,vector,max);
	printf("En C el mayor valor del vector es : %d\n",*max);

	asmMayorNumero(len,vector,max);
	printf("En Asm el mayor valor del vector es : %d\n",*max);
	return 0;
}

void cMayorNumero(int len , int *vector , int *max){
	*max = 0;
	for(int i=0;i<len;i++){
		if(vector[i]>*max){
			*max = vector[i];
		}
	}
}